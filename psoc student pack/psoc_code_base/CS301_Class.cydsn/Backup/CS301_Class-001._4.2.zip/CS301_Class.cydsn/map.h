#pragma once
#include <stdio.h>

extern int map[15][19];
extern int food_list[5][2];